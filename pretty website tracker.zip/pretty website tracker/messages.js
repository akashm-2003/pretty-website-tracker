var Messages = /* @__PURE__ */ ((Messages2) => {
  Messages2["RescheduleJobs"] = "reschedule-jobs";
  Messages2["ClearAllData"] = "clear-data";
  Messages2["Restore"] = "restore-data";
  Messages2["PlayAudio"] = "play-audio";
  return Messages2;
})(Messages || {});
export {
  Messages as M
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVzc2FnZXMuanMiLCJzb3VyY2VzIjpbIi4uL3NyYy91dGlscy9tZXNzYWdlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZW51bSBNZXNzYWdlcyB7XG4gIFJlc2NoZWR1bGVKb2JzID0gJ3Jlc2NoZWR1bGUtam9icycsXG4gIENsZWFyQWxsRGF0YSA9ICdjbGVhci1kYXRhJyxcbiAgUmVzdG9yZSA9ICdyZXN0b3JlLWRhdGEnLFxuICBQbGF5QXVkaW8gPSAncGxheS1hdWRpbycsXG59XG4iXSwibmFtZXMiOlsiTWVzc2FnZXMiXSwibWFwcGluZ3MiOiJBQUFZLElBQUEsNkJBQUFBLGNBQUw7QUFDTEEsWUFBQSxnQkFBaUIsSUFBQTtBQUNqQkEsWUFBQSxjQUFlLElBQUE7QUFDZkEsWUFBQSxTQUFVLElBQUE7QUFDVkEsWUFBQSxXQUFZLElBQUE7QUFKRkEsU0FBQUE7QUFBQSxHQUFBLFlBQUEsQ0FBQSxDQUFBOyJ9
