import { d as defineComponent, r as ref, o as openBlock, c as createElementBlock, a as createBaseVNode, n as normalizeClass, b as createTextVNode, t as toDisplayString, u as unref, e as convertSummaryTimeToString, f as createVNode, w as withCtx, g as withDirectives, h as renderSlot, v as vShow, T as Transition, p as pushScopeId, i as popScopeId, _ as _export_sfc, j as useI18n, k as ranges, l as computed, m as onMounted, q as ThisWeekRange, s as resolveComponent, x as createBlock, F as Fragment, y as renderList, z as createCommentVNode, A as _imports_0$1, B as createApp, C as i18n } from "../general.js";
import { _ as _sfc_main$3, B as ByDaysChart, T as TabItem, u as useTabListByDays, a as useImportToCsvWithData, b as useFile, F as FileType, c as _imports_0, d as TypeOfList, e as TabList, o as openPage, S as SettingsTab, f as oa } from "../main.js";
const _imports_1 = "/dashboard.svg";
const _imports_2 = "/settings.svg";
const _withScopeId$2 = (n) => (pushScopeId("data-v-677b5a4c"), n = n(), popScopeId(), n);
const _hoisted_1$2 = { class: "expander" };
const _hoisted_2$2 = { class: "d-inline-block" };
const _hoisted_3$2 = /* @__PURE__ */ _withScopeId$2(() => /* @__PURE__ */ createBaseVNode("polyline", {
  points: "12,2 20,10 28,2",
  "stroke-width": "3",
  fill: "none"
}, null, -1));
const _hoisted_4$2 = [
  _hoisted_3$2
];
const _hoisted_5$2 = { class: "header" };
const _hoisted_6$2 = { class: "expander-body" };
const __default__$1 = {
  name: "Expander"
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...__default__$1,
  props: {
    day: {},
    time: {}
  },
  setup(__props) {
    const open = ref();
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("div", {
          class: normalizeClass(["expander-trigger", open.value ? "active" : "beforeBorder"]),
          onClick: _cache[0] || (_cache[0] = ($event) => open.value = !open.value)
        }, [
          createBaseVNode("div", _hoisted_2$2, [
            (openBlock(), createElementBlock("svg", {
              class: normalizeClass(["expander-trigger-Icon", { open: open.value }]),
              width: "40",
              height: "12",
              stroke: "cornflowerblue"
            }, _hoisted_4$2, 2))
          ]),
          createBaseVNode("div", _hoisted_5$2, [
            createTextVNode(toDisplayString(_ctx.day) + " ", 1),
            createBaseVNode("span", null, toDisplayString(unref(convertSummaryTimeToString)(_ctx.time)), 1)
          ])
        ], 2),
        createVNode(Transition, { name: "leftToRight" }, {
          default: withCtx(() => [
            withDirectives(createBaseVNode("div", _hoisted_6$2, [
              renderSlot(_ctx.$slots, "default", {}, void 0, true)
            ], 512), [
              [vShow, open.value]
            ])
          ]),
          _: 3
        })
      ]);
    };
  }
});
const Expander_vue_vue_type_style_index_0_scoped_677b5a4c_lang = "";
const Expander = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-677b5a4c"]]);
const _withScopeId$1 = (n) => (pushScopeId("data-v-bce2236d"), n = n(), popScopeId(), n);
const _hoisted_1$1 = {
  key: 0,
  class: "no-data"
};
const _hoisted_2$1 = /* @__PURE__ */ _withScopeId$1(() => /* @__PURE__ */ createBaseVNode("img", {
  height: "55",
  src: _imports_0
}, null, -1));
const _hoisted_3$1 = [
  _hoisted_2$1
];
const _hoisted_4$1 = { key: 1 };
const _hoisted_5$1 = { key: 1 };
const _hoisted_6$1 = { class: "no-data" };
const _hoisted_7$1 = ["onClick"];
const _hoisted_8$1 = { key: 2 };
const _hoisted_9$1 = { class: "date-block" };
const _hoisted_10$1 = ["onClick"];
const _hoisted_11$1 = ["value"];
const _hoisted_12$1 = { class: "stats-block block" };
const _hoisted_13$1 = { class: "header" };
const _hoisted_14$1 = { class: "ml-20 mr-20 by-days-chart" };
const __default__ = {
  name: "TabList"
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  ...__default__,
  setup(__props) {
    const { t } = useI18n();
    const tabsByDays = ref();
    const isLoading = ref();
    const noData = ref();
    const selectedDate = ref();
    const presetRanges = ranges();
    const countOfDays = computed(
      () => tabsByDays.value != void 0 ? tabsByDays.value.days.length : 0
    );
    async function loadList(dateFrom, dateTo) {
      const tabList = await useTabListByDays(dateFrom, dateTo);
      if (tabList != null) {
        tabsByDays.value = tabList;
        if (tabList.days.length == 0 && tabList.summaryTime == 0)
          noData.value = true;
        else
          noData.value = false;
      }
      isLoading.value = false;
    }
    async function handleDate(modelData) {
      var _a, _b;
      selectedDate.value = modelData;
      const dateFrom = (_a = selectedDate.value) == null ? void 0 : _a[0];
      const dateTo = (_b = selectedDate.value) == null ? void 0 : _b[1];
      await loadList(dateFrom, dateTo);
    }
    onMounted(async () => {
      var _a, _b;
      isLoading.value = true;
      selectedDate.value = ThisWeekRange;
      const dateFrom = (_a = selectedDate.value) == null ? void 0 : _a[0];
      const dateTo = (_b = selectedDate.value) == null ? void 0 : _b[1];
      await loadList(dateFrom, dateTo);
    });
    async function exportToCsv() {
      var _a, _b, _c;
      const dateFrom = (_a = selectedDate.value) == null ? void 0 : _a[0];
      const dateTo = (_b = selectedDate.value) == null ? void 0 : _b[1];
      const csv = await useImportToCsvWithData((_c = tabsByDays.value) == null ? void 0 : _c.days);
      useFile(
        csv,
        FileType.CSV,
        `websites_${dateFrom.toLocaleDateString()}-${dateTo.toLocaleDateString()}.csv`
      );
    }
    return (_ctx, _cache) => {
      var _a;
      const _component_VueDatePicker = resolveComponent("VueDatePicker");
      return isLoading.value ? (openBlock(), createElementBlock("div", _hoisted_1$1, _hoisted_3$1)) : (openBlock(), createElementBlock("div", _hoisted_4$1, [
        countOfDays.value == void 0 || countOfDays.value == 0 && !noData.value ? (openBlock(), createBlock(_sfc_main$3, { key: 0 })) : noData.value ? (openBlock(), createElementBlock("div", _hoisted_5$1, [
          createBaseVNode("div", _hoisted_6$1, [
            createTextVNode(toDisplayString(unref(t)("noDataForPeriod.message")) + " ", 1),
            createVNode(_component_VueDatePicker, {
              range: "",
              "enable-time-picker": false,
              class: "date-picker",
              modelValue: selectedDate.value,
              "onUpdate:modelValue": [
                _cache[0] || (_cache[0] = ($event) => selectedDate.value = $event),
                handleDate
              ],
              "preset-ranges": unref(presetRanges)
            }, {
              yearly: withCtx(({ label, range, presetDateRange }) => [
                createBaseVNode("span", {
                  onClick: ($event) => presetDateRange(range)
                }, toDisplayString(label), 9, _hoisted_7$1)
              ]),
              _: 1
            }, 8, ["modelValue", "preset-ranges"])
          ])
        ])) : (openBlock(), createElementBlock("div", _hoisted_8$1, [
          createBaseVNode("div", _hoisted_9$1, [
            createVNode(_component_VueDatePicker, {
              range: "",
              "enable-time-picker": false,
              class: "date-picker",
              modelValue: selectedDate.value,
              "onUpdate:modelValue": [
                _cache[1] || (_cache[1] = ($event) => selectedDate.value = $event),
                handleDate
              ],
              "preset-ranges": unref(presetRanges)
            }, {
              yearly: withCtx(({ label, range, presetDateRange }) => [
                createBaseVNode("span", {
                  onClick: ($event) => presetDateRange(range)
                }, toDisplayString(label), 9, _hoisted_10$1)
              ]),
              _: 1
            }, 8, ["modelValue", "preset-ranges"]),
            createBaseVNode("input", {
              type: "button",
              value: unref(t)("exportToCsv.message"),
              onClick: _cache[2] || (_cache[2] = ($event) => exportToCsv())
            }, null, 8, _hoisted_11$1)
          ]),
          createBaseVNode("div", _hoisted_12$1, [
            createBaseVNode("div", _hoisted_13$1, toDisplayString(unref(t)("averageTimeByDays.message")), 1),
            createBaseVNode("p", null, toDisplayString(unref(convertSummaryTimeToString)(tabsByDays.value.averageTime)), 1)
          ]),
          createBaseVNode("div", _hoisted_14$1, [
            createVNode(ByDaysChart, {
              data: tabsByDays.value
            }, null, 8, ["data"])
          ]),
          createBaseVNode("div", null, [
            (openBlock(true), createElementBlock(Fragment, null, renderList((_a = tabsByDays.value) == null ? void 0 : _a.days, (tabDay, i) => {
              return openBlock(), createBlock(Expander, {
                key: i,
                day: tabDay.day,
                time: tabDay.time
              }, {
                default: withCtx(() => [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(tabDay.tabs, (tab, i2) => {
                    return openBlock(), createBlock(TabItem, {
                      key: i2,
                      item: tab,
                      summaryTimeForWholeDay: tabDay.time
                    }, null, 8, ["item", "summaryTimeForWholeDay"]);
                  }), 128))
                ]),
                _: 2
              }, 1032, ["day", "time"]);
            }), 128))
          ])
        ]))
      ]));
    };
  }
});
const ByDays_vue_vue_type_style_index_0_scoped_bce2236d_lang = "";
const ByDays = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-bce2236d"]]);
const _withScopeId = (n) => (pushScopeId("data-v-b9cbcd79"), n = n(), popScopeId(), n);
const _hoisted_1 = { class: "headerBlock" };
const _hoisted_2 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "d-inline-block" }, [
  /* @__PURE__ */ createBaseVNode("img", {
    class: "logo",
    height: "30",
    src: _imports_0$1
  }),
  /* @__PURE__ */ createBaseVNode("p", { class: "header" }, "Pretty Website Tracker")
], -1));
const _hoisted_3 = { class: "icons-block" };
const _hoisted_4 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("img", {
  height: "22",
  src: _imports_1
}, null, -1));
const _hoisted_5 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("img", {
  height: "22",
  src: _imports_2
}, null, -1));
const _hoisted_6 = { class: "tabs" };
const _hoisted_7 = { title: "Today" };
const _hoisted_8 = {
  for: "todayTab",
  role: "button"
};
const _hoisted_9 = { title: "All The Time" };
const _hoisted_10 = {
  for: "allTimeTab",
  role: "button"
};
const _hoisted_11 = { title: "By Days" };
const _hoisted_12 = {
  for: "byDaysTab",
  role: "button"
};
const _hoisted_13 = /* @__PURE__ */ _withScopeId(() => /* @__PURE__ */ createBaseVNode("div", { class: "slider" }, [
  /* @__PURE__ */ createBaseVNode("div", { class: "indicator" })
], -1));
const _hoisted_14 = { class: "content" };
const _hoisted_15 = { id: "todayTabList" };
const _hoisted_16 = { id: "summary" };
const _hoisted_17 = { id: "byDaysTabList" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Popup",
  setup(__props) {
    const { t } = useI18n();
    const activeTab = ref();
    onMounted(async () => {
      activeTab.value = TypeOfList.Today;
    });
    function selectTab(type) {
      activeTab.value = type;
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1, [
          _hoisted_2,
          createBaseVNode("div", _hoisted_3, [
            createBaseVNode("a", {
              class: "filter",
              onClick: _cache[0] || (_cache[0] = ($event) => unref(openPage)(unref(SettingsTab).Dashboard))
            }, [
              createTextVNode(toDisplayString(unref(t)("dashboard.message")), 1),
              _hoisted_4
            ]),
            createBaseVNode("a", {
              class: "filter",
              onClick: _cache[1] || (_cache[1] = ($event) => unref(openPage)(unref(SettingsTab).GeneralSettings))
            }, [
              createTextVNode(toDisplayString(unref(t)("settings.message")), 1),
              _hoisted_5
            ])
          ])
        ]),
        createBaseVNode("div", _hoisted_6, [
          createBaseVNode("input", {
            type: "radio",
            id: "todayTab",
            name: "tab-control",
            checked: "",
            onChange: _cache[2] || (_cache[2] = ($event) => selectTab(unref(TypeOfList).Today))
          }, null, 32),
          createBaseVNode("input", {
            type: "radio",
            id: "allTimeTab",
            name: "tab-control",
            onChange: _cache[3] || (_cache[3] = ($event) => selectTab(unref(TypeOfList).All))
          }, null, 32),
          createBaseVNode("input", {
            type: "radio",
            id: "byDaysTab",
            name: "tab-control",
            onChange: _cache[4] || (_cache[4] = ($event) => selectTab(unref(TypeOfList).ByDays))
          }, null, 32),
          createBaseVNode("ul", null, [
            createBaseVNode("li", _hoisted_7, [
              createBaseVNode("label", _hoisted_8, [
                createBaseVNode("span", null, toDisplayString(unref(t)("today.message")), 1)
              ])
            ]),
            createBaseVNode("li", _hoisted_9, [
              createBaseVNode("label", _hoisted_10, [
                createBaseVNode("span", null, toDisplayString(unref(t)("allTime.message")), 1)
              ])
            ]),
            createBaseVNode("li", _hoisted_11, [
              createBaseVNode("label", _hoisted_12, [
                createBaseVNode("span", null, toDisplayString(unref(t)("byDays.message")), 1)
              ])
            ])
          ]),
          _hoisted_13,
          createBaseVNode("div", _hoisted_14, [
            createBaseVNode("section", _hoisted_15, [
              activeTab.value == unref(TypeOfList).Today ? (openBlock(), createBlock(TabList, {
                key: 0,
                type: unref(TypeOfList).Today,
                showAllStats: false
              }, null, 8, ["type"])) : createCommentVNode("", true)
            ]),
            createBaseVNode("section", _hoisted_16, [
              activeTab.value == unref(TypeOfList).All ? (openBlock(), createBlock(TabList, {
                key: 0,
                type: unref(TypeOfList).All,
                showAllStats: true
              }, null, 8, ["type"])) : createCommentVNode("", true)
            ]),
            createBaseVNode("section", _hoisted_17, [
              activeTab.value == unref(TypeOfList).ByDays ? (openBlock(), createBlock(ByDays, { key: 0 })) : createCommentVNode("", true)
            ])
          ])
        ])
      ], 64);
    };
  }
});
const Popup_vue_vue_type_style_index_0_scoped_b9cbcd79_lang = "";
const Popup = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b9cbcd79"]]);
const app = createApp(Popup);
app.component("VueDatePicker", oa);
app.use(i18n);
app.mount("body");
const main = "";
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9hc3NldHMvaWNvbnMvZGFzaGJvYXJkLnN2ZyIsIi4uLy4uL3NyYy9hc3NldHMvaWNvbnMvc2V0dGluZ3Muc3ZnIiwiLi4vLi4vc3JjL2NvbXBvbmVudHMvRXhwYW5kZXIudnVlIiwiLi4vLi4vc3JjL2NvbXBvbmVudHMvQnlEYXlzLnZ1ZSIsIi4uLy4uL3NyYy9wYWdlcy9Qb3B1cC52dWUiLCIuLi8uLi9zcmMvcG9wdXAudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgXCJfX1ZJVEVfQVNTRVRfXzhhMzZkODQ0X19cIiIsImV4cG9ydCBkZWZhdWx0IFwiX19WSVRFX0FTU0VUX184NjJjZWU0Y19fXCIiLCI8dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJleHBhbmRlclwiPlxuICAgIDxkaXYgY2xhc3M9XCJleHBhbmRlci10cmlnZ2VyXCIgQGNsaWNrPVwib3BlbiA9ICFvcGVuXCIgOmNsYXNzPVwib3BlbiA/ICdhY3RpdmUnIDogJ2JlZm9yZUJvcmRlcidcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkLWlubGluZS1ibG9ja1wiPlxuICAgICAgICA8c3ZnXG4gICAgICAgICAgY2xhc3M9XCJleHBhbmRlci10cmlnZ2VyLUljb25cIlxuICAgICAgICAgIDpjbGFzcz1cInsgb3Blbjogb3BlbiB9XCJcbiAgICAgICAgICB3aWR0aD1cIjQwXCJcbiAgICAgICAgICBoZWlnaHQ9XCIxMlwiXG4gICAgICAgICAgc3Ryb2tlPVwiY29ybmZsb3dlcmJsdWVcIlxuICAgICAgICA+XG4gICAgICAgICAgPHBvbHlsaW5lIHBvaW50cz1cIjEyLDIgMjAsMTAgMjgsMlwiIHN0cm9rZS13aWR0aD1cIjNcIiBmaWxsPVwibm9uZVwiPjwvcG9seWxpbmU+XG4gICAgICAgIDwvc3ZnPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+XG4gICAgICAgIHt7IGRheSB9fVxuICAgICAgICA8c3Bhbj57eyBjb252ZXJ0U3VtbWFyeVRpbWVUb1N0cmluZyh0aW1lKSB9fTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDx0cmFuc2l0aW9uIG5hbWU9XCJsZWZ0VG9SaWdodFwiPlxuICAgICAgPGRpdiBjbGFzcz1cImV4cGFuZGVyLWJvZHlcIiB2LXNob3c9XCJvcGVuXCI+XG4gICAgICAgIDxzbG90Pjwvc2xvdD5cbiAgICAgIDwvZGl2PlxuICAgIDwvdHJhbnNpdGlvbj5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c2NyaXB0IGxhbmc9XCJ0c1wiPlxuZXhwb3J0IGRlZmF1bHQge1xuICBuYW1lOiAnRXhwYW5kZXInLFxufTtcbjwvc2NyaXB0PlxuXG48c2NyaXB0IGxhbmc9XCJ0c1wiIHNldHVwPlxuaW1wb3J0IHsgcmVmIH0gZnJvbSAndnVlJztcbmltcG9ydCB7IGNvbnZlcnRTdW1tYXJ5VGltZVRvU3RyaW5nIH0gZnJvbSAnLi4vdXRpbHMvY29udmVydGVyJztcblxuY29uc3QgcHJvcHMgPSBkZWZpbmVQcm9wczx7XG4gIGRheTogc3RyaW5nO1xuICB0aW1lOiBudW1iZXI7XG59PigpO1xuXG5jb25zdCBvcGVuID0gcmVmPGJvb2xlYW4+KCk7XG48L3NjcmlwdD5cblxuPHN0eWxlIHNjb3BlZD5cbi5oZWFkZXIge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiA5MCU7XG59XG4uaGVhZGVyIHNwYW4ge1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiByZ2IoNTksIDU5LCA1OSk7XG4gIGZsb2F0OiByaWdodDtcbn1cbi5leHBhbmRlci10cmlnZ2VyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBwYWRkaW5nOiAwLjdyZW0gMC41cmVtO1xuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2VmZWZlZjtcbn1cbi5leHBhbmRlci10cmlnZ2VyOmhvdmVyIHtcbiAgY29sb3I6ICM0NzdkY2E7XG59XG4uZXhwYW5kZXItdHJpZ2dlci5hY3RpdmUge1xuICBib3JkZXItYm90dG9tLWNvbG9yOiAjNDc3ZGNhO1xufVxuLmV4cGFuZGVyLXRyaWdnZXItSWNvbiB7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjJzIGN1YmljLWJlemllcigwLjIzLCAxLCAwLjMyLCAxKTtcbn1cbi5leHBhbmRlci10cmlnZ2VyLUljb24ub3BlbiB7XG4gIHN0cm9rZTogI2ZmNjM0NztcbiAgdHJhbnNmb3JtOiByb3RhdGUoMTgwZGVnKTtcbn1cbi5leHBhbmRlci1ib2R5IHtcbiAgcGFkZGluZzogMXB4O1xuICBiYWNrZ3JvdW5kOiAjZWZmMGYyO1xufVxuLmxlZnRUb1JpZ2h0LWVudGVyLWFjdGl2ZSB7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBsZWZ0VG9SaWdodCAwLjVzO1xuICBhbmltYXRpb246IGxlZnRUb1JpZ2h0IDAuNXM7XG59XG4ubGVmdFRvUmlnaHQtbGVhdmUtYWN0aXZlIHtcbiAgYW5pbWF0aW9uOiBsZWZ0VG9SaWdodCAwLjVzIHJldmVyc2U7XG59XG5ALXdlYmtpdC1rZXlmcmFtZXMgbGVmdFRvUmlnaHQge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0xMDB2dyk7XG4gIH1cbiAgNTAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMmVtKTtcbiAgfVxuICAxMDAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XG4gIH1cbn1cbkBrZXlmcmFtZXMgbGVmdFRvUmlnaHQge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC0xMDB2dyk7XG4gIH1cbiAgNTAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMmVtKTtcbiAgfVxuICAxMDAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMCk7XG4gIH1cbn1cbjwvc3R5bGU+XG4iLCI8dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJuby1kYXRhXCIgdi1pZj1cImlzTG9hZGluZ1wiPlxuICAgIDxpbWcgaGVpZ2h0PVwiNTVcIiBzcmM9XCIuLi9hc3NldHMvaWNvbnMvcHJlbG9hZGVyLmdpZlwiIC8+XG4gIDwvZGl2PlxuICA8ZGl2IHYtZWxzZT5cbiAgICA8bm8tZGF0YS1ieS1kYXlzIHYtaWY9XCJjb3VudE9mRGF5cyA9PSB1bmRlZmluZWQgfHwgKGNvdW50T2ZEYXlzID09IDAgJiYgIW5vRGF0YSlcIiAvPlxuICAgIDxkaXYgdi1lbHNlLWlmPVwibm9EYXRhXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibm8tZGF0YVwiPlxuICAgICAgICB7eyB0KCdub0RhdGFGb3JQZXJpb2QubWVzc2FnZScpIH19XG4gICAgICAgIDxWdWVEYXRlUGlja2VyXG4gICAgICAgICAgcmFuZ2VcbiAgICAgICAgICA6ZW5hYmxlLXRpbWUtcGlja2VyPVwiZmFsc2VcIlxuICAgICAgICAgIGNsYXNzPVwiZGF0ZS1waWNrZXJcIlxuICAgICAgICAgIHYtbW9kZWw9XCJzZWxlY3RlZERhdGVcIlxuICAgICAgICAgIDpwcmVzZXQtcmFuZ2VzPVwicHJlc2V0UmFuZ2VzXCJcbiAgICAgICAgICBAdXBkYXRlOm1vZGVsLXZhbHVlPVwiaGFuZGxlRGF0ZVwiXG4gICAgICAgID5cbiAgICAgICAgICA8dGVtcGxhdGUgI3llYXJseT1cInsgbGFiZWwsIHJhbmdlLCBwcmVzZXREYXRlUmFuZ2UgfVwiPlxuICAgICAgICAgICAgPHNwYW4gQGNsaWNrPVwicHJlc2V0RGF0ZVJhbmdlKHJhbmdlKVwiPnt7IGxhYmVsIH19PC9zcGFuPlxuICAgICAgICAgIDwvdGVtcGxhdGU+PC9WdWVEYXRlUGlja2VyXG4gICAgICAgID5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICAgIDxkaXYgdi1lbHNlPlxuICAgICAgPGRpdiBjbGFzcz1cImRhdGUtYmxvY2tcIj5cbiAgICAgICAgPFZ1ZURhdGVQaWNrZXJcbiAgICAgICAgICByYW5nZVxuICAgICAgICAgIDplbmFibGUtdGltZS1waWNrZXI9XCJmYWxzZVwiXG4gICAgICAgICAgY2xhc3M9XCJkYXRlLXBpY2tlclwiXG4gICAgICAgICAgdi1tb2RlbD1cInNlbGVjdGVkRGF0ZVwiXG4gICAgICAgICAgOnByZXNldC1yYW5nZXM9XCJwcmVzZXRSYW5nZXNcIlxuICAgICAgICAgIEB1cGRhdGU6bW9kZWwtdmFsdWU9XCJoYW5kbGVEYXRlXCJcbiAgICAgICAgPlxuICAgICAgICAgIDx0ZW1wbGF0ZSAjeWVhcmx5PVwieyBsYWJlbCwgcmFuZ2UsIHByZXNldERhdGVSYW5nZSB9XCI+XG4gICAgICAgICAgICA8c3BhbiBAY2xpY2s9XCJwcmVzZXREYXRlUmFuZ2UocmFuZ2UpXCI+e3sgbGFiZWwgfX08L3NwYW4+XG4gICAgICAgICAgPC90ZW1wbGF0ZT48L1Z1ZURhdGVQaWNrZXJcbiAgICAgICAgPlxuICAgICAgICA8aW5wdXQgdHlwZT1cImJ1dHRvblwiIDp2YWx1ZT1cInQoJ2V4cG9ydFRvQ3N2Lm1lc3NhZ2UnKVwiIEBjbGljaz1cImV4cG9ydFRvQ3N2KClcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwic3RhdHMtYmxvY2sgYmxvY2tcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImhlYWRlclwiPnt7IHQoJ2F2ZXJhZ2VUaW1lQnlEYXlzLm1lc3NhZ2UnKSB9fTwvZGl2PlxuICAgICAgICA8cD57eyBjb252ZXJ0U3VtbWFyeVRpbWVUb1N0cmluZyh0YWJzQnlEYXlzIS5hdmVyYWdlVGltZSkgfX08L3A+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJtbC0yMCBtci0yMCBieS1kYXlzLWNoYXJ0XCI+XG4gICAgICAgIDxCeURheXNDaGFydCA6ZGF0YT1cInRhYnNCeURheXMhXCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdj5cbiAgICAgICAgPEV4cGFuZGVyXG4gICAgICAgICAgdi1mb3I9XCIodGFiRGF5LCBpKSBvZiB0YWJzQnlEYXlzPy5kYXlzXCJcbiAgICAgICAgICA6a2V5PVwiaVwiXG4gICAgICAgICAgOmRheT1cInRhYkRheS5kYXlcIlxuICAgICAgICAgIDp0aW1lPVwidGFiRGF5LnRpbWVcIlxuICAgICAgICA+XG4gICAgICAgICAgPFRhYkl0ZW1cbiAgICAgICAgICAgIHYtZm9yPVwiKHRhYiwgaSkgb2YgdGFiRGF5LnRhYnNcIlxuICAgICAgICAgICAgOmtleT1cImlcIlxuICAgICAgICAgICAgOml0ZW09XCJ0YWJcIlxuICAgICAgICAgICAgOnN1bW1hcnlUaW1lRm9yV2hvbGVEYXk9XCJ0YWJEYXkudGltZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9FeHBhbmRlcj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgbGFuZz1cInRzXCI+XG5leHBvcnQgZGVmYXVsdCB7XG4gIG5hbWU6ICdUYWJMaXN0Jyxcbn07XG48L3NjcmlwdD5cblxuPHNjcmlwdCBsYW5nPVwidHNcIiBzZXR1cD5cbmltcG9ydCB7IGNvbXB1dGVkLCBvbk1vdW50ZWQsIHJlZiB9IGZyb20gJ3Z1ZSc7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAndnVlLWkxOG4nO1xuaW1wb3J0IFRhYkl0ZW0gZnJvbSAnLi4vY29tcG9uZW50cy9UYWJJdGVtLnZ1ZSc7XG5pbXBvcnQgTm9EYXRhQnlEYXlzIGZyb20gJy4vTm9EYXRhQnlEYXlzLnZ1ZSc7XG5pbXBvcnQgQnlEYXlzQ2hhcnQgZnJvbSAnLi4vY29tcG9uZW50cy9CeURheXNDaGFydC52dWUnO1xuaW1wb3J0IEV4cGFuZGVyIGZyb20gJy4uL2NvbXBvbmVudHMvRXhwYW5kZXIudnVlJztcbmltcG9ydCB7IFRhYkxpc3RCeURheXMgfSBmcm9tICcuLi9kdG8vdGFiTGlzdFN1bW1hcnknO1xuaW1wb3J0IHsgdXNlVGFiTGlzdEJ5RGF5cyB9IGZyb20gJy4uL2Z1bmN0aW9ucy91c2VUYWJMaXN0QnlEYXlzJztcbmltcG9ydCB7IGNvbnZlcnRTdW1tYXJ5VGltZVRvU3RyaW5nIH0gZnJvbSAnLi4vdXRpbHMvY29udmVydGVyJztcbmltcG9ydCB7IHJhbmdlcywgVGhpc1dlZWtSYW5nZSB9IGZyb20gJy4uL3V0aWxzL2RhdGUnO1xuaW1wb3J0IHsgdXNlSW1wb3J0VG9Dc3ZXaXRoRGF0YSB9IGZyb20gJy4uL2Z1bmN0aW9ucy91c2VJbXBvcnRUb0Nzdic7XG5pbXBvcnQgeyB1c2VGaWxlLCBGaWxlVHlwZSB9IGZyb20gJy4uL2Z1bmN0aW9ucy91c2VGaWxlJztcblxuY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG5cbmNvbnN0IHRhYnNCeURheXMgPSByZWY8VGFiTGlzdEJ5RGF5cz4oKTtcbmNvbnN0IGlzTG9hZGluZyA9IHJlZjxib29sZWFuPigpO1xuY29uc3Qgbm9EYXRhID0gcmVmPGJvb2xlYW4+KCk7XG5jb25zdCBzZWxlY3RlZERhdGUgPSByZWY8RGF0ZVtdPigpO1xuXG5jb25zdCBwcmVzZXRSYW5nZXMgPSByYW5nZXMoKTtcblxuY29uc3QgY291bnRPZkRheXMgPSBjb21wdXRlZCgoKSA9PlxuICB0YWJzQnlEYXlzLnZhbHVlICE9IHVuZGVmaW5lZCA/IHRhYnNCeURheXMudmFsdWUuZGF5cy5sZW5ndGggOiAwLFxuKTtcblxuYXN5bmMgZnVuY3Rpb24gbG9hZExpc3QoZGF0ZUZyb206IERhdGUsIGRhdGVUbzogRGF0ZSkge1xuICBjb25zdCB0YWJMaXN0ID0gYXdhaXQgdXNlVGFiTGlzdEJ5RGF5cyhkYXRlRnJvbSwgZGF0ZVRvKTtcbiAgaWYgKHRhYkxpc3QgIT0gbnVsbCkge1xuICAgIHRhYnNCeURheXMudmFsdWUgPSB0YWJMaXN0O1xuICAgIGlmICh0YWJMaXN0LmRheXMubGVuZ3RoID09IDAgJiYgdGFiTGlzdC5zdW1tYXJ5VGltZSA9PSAwKSBub0RhdGEudmFsdWUgPSB0cnVlO1xuICAgIGVsc2Ugbm9EYXRhLnZhbHVlID0gZmFsc2U7XG4gIH1cbiAgaXNMb2FkaW5nLnZhbHVlID0gZmFsc2U7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURhdGUobW9kZWxEYXRhOiBEYXRlW10pIHtcbiAgc2VsZWN0ZWREYXRlLnZhbHVlID0gbW9kZWxEYXRhO1xuICBjb25zdCBkYXRlRnJvbSA9IHNlbGVjdGVkRGF0ZS52YWx1ZT8uWzBdIGFzIERhdGU7XG4gIGNvbnN0IGRhdGVUbyA9IHNlbGVjdGVkRGF0ZS52YWx1ZT8uWzFdIGFzIERhdGU7XG4gIGF3YWl0IGxvYWRMaXN0KGRhdGVGcm9tLCBkYXRlVG8pO1xufVxuXG5vbk1vdW50ZWQoYXN5bmMgKCkgPT4ge1xuICBpc0xvYWRpbmcudmFsdWUgPSB0cnVlO1xuICBzZWxlY3RlZERhdGUudmFsdWUgPSBUaGlzV2Vla1JhbmdlO1xuICBjb25zdCBkYXRlRnJvbSA9IHNlbGVjdGVkRGF0ZS52YWx1ZT8uWzBdIGFzIERhdGU7XG4gIGNvbnN0IGRhdGVUbyA9IHNlbGVjdGVkRGF0ZS52YWx1ZT8uWzFdIGFzIERhdGU7XG4gIGF3YWl0IGxvYWRMaXN0KGRhdGVGcm9tLCBkYXRlVG8pO1xufSk7XG5cbmFzeW5jIGZ1bmN0aW9uIGV4cG9ydFRvQ3N2KCkge1xuICBjb25zdCBkYXRlRnJvbSA9IHNlbGVjdGVkRGF0ZS52YWx1ZT8uWzBdIGFzIERhdGU7XG4gIGNvbnN0IGRhdGVUbyA9IHNlbGVjdGVkRGF0ZS52YWx1ZT8uWzFdIGFzIERhdGU7XG4gIGNvbnN0IGNzdiA9IGF3YWl0IHVzZUltcG9ydFRvQ3N2V2l0aERhdGEodGFic0J5RGF5cy52YWx1ZT8uZGF5cyk7XG4gIHVzZUZpbGUoXG4gICAgY3N2LFxuICAgIEZpbGVUeXBlLkNTVixcbiAgICBgd2Vic2l0ZXNfJHtkYXRlRnJvbS50b0xvY2FsZURhdGVTdHJpbmcoKX0tJHtkYXRlVG8udG9Mb2NhbGVEYXRlU3RyaW5nKCl9LmNzdmAsXG4gICk7XG59XG48L3NjcmlwdD5cblxuPHN0eWxlIHNjb3BlZD5cbi5zdGF0cy1ibG9jay5ibG9jayB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xuICBtYXJnaW46IDEwcHggMjVweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4uc3RhdHMtYmxvY2suYmxvY2sgLmhlYWRlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLXBvcHVwLWhlYWRlcik7XG4gIGNvbG9yOiByZ2IoNjYsIDY2LCA2Nik7XG4gIHBhZGRpbmc6IDVweCA1cHg7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cblxuLnN0YXRzLWJsb2NrLmJsb2NrIHAge1xuICBtYXJnaW46IDJweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXdlaWdodDogNzAwO1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiByZ2IoNTksIDU5LCA1OSk7XG59XG4uZGF0ZS1ibG9jayB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgbWFyZ2luOiAwIDI1cHg7XG59XG4uYnktZGF5cy1jaGFydCB7XG4gIGhlaWdodDogMjQwcHg7XG59XG48L3N0eWxlPlxuIiwiPHRlbXBsYXRlPlxuICA8ZGl2IGNsYXNzPVwiaGVhZGVyQmxvY2tcIj5cbiAgICA8ZGl2IGNsYXNzPVwiZC1pbmxpbmUtYmxvY2tcIj5cbiAgICAgIDxpbWcgY2xhc3M9XCJsb2dvXCIgaGVpZ2h0PVwiMzBcIiBzcmM9XCIuLi9hc3NldHMvaWNvbnMvNDh4NDgucG5nXCIgLz5cbiAgICAgIDxwIGNsYXNzPVwiaGVhZGVyXCI+UHJldHR5IFdlYnNpdGUgVHJhY2tlcjwvcD5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiaWNvbnMtYmxvY2tcIj5cbiAgICAgIDxhIGNsYXNzPVwiZmlsdGVyXCIgQGNsaWNrPVwib3BlblBhZ2UoU2V0dGluZ3NUYWIuRGFzaGJvYXJkKVwiXG4gICAgICAgID57eyB0KCdkYXNoYm9hcmQubWVzc2FnZScpIH19PGltZyBoZWlnaHQ9XCIyMlwiIHNyYz1cIi4uL2Fzc2V0cy9pY29ucy9kYXNoYm9hcmQuc3ZnXCJcbiAgICAgIC8+PC9hPlxuICAgICAgPGEgY2xhc3M9XCJmaWx0ZXJcIiBAY2xpY2s9XCJvcGVuUGFnZShTZXR0aW5nc1RhYi5HZW5lcmFsU2V0dGluZ3MpXCJcbiAgICAgICAgPnt7IHQoJ3NldHRpbmdzLm1lc3NhZ2UnKSB9fTxpbWcgaGVpZ2h0PVwiMjJcIiBzcmM9XCIuLi9hc3NldHMvaWNvbnMvc2V0dGluZ3Muc3ZnXCJcbiAgICAgIC8+PC9hPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbiAgPGRpdiBjbGFzcz1cInRhYnNcIj5cbiAgICA8aW5wdXRcbiAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICBpZD1cInRvZGF5VGFiXCJcbiAgICAgIG5hbWU9XCJ0YWItY29udHJvbFwiXG4gICAgICBjaGVja2VkXG4gICAgICB2LW9uOmNoYW5nZT1cInNlbGVjdFRhYihUeXBlT2ZMaXN0LlRvZGF5KVwiXG4gICAgLz5cbiAgICA8aW5wdXRcbiAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICBpZD1cImFsbFRpbWVUYWJcIlxuICAgICAgbmFtZT1cInRhYi1jb250cm9sXCJcbiAgICAgIHYtb246Y2hhbmdlPVwic2VsZWN0VGFiKFR5cGVPZkxpc3QuQWxsKVwiXG4gICAgLz5cbiAgICA8aW5wdXRcbiAgICAgIHR5cGU9XCJyYWRpb1wiXG4gICAgICBpZD1cImJ5RGF5c1RhYlwiXG4gICAgICBuYW1lPVwidGFiLWNvbnRyb2xcIlxuICAgICAgdi1vbjpjaGFuZ2U9XCJzZWxlY3RUYWIoVHlwZU9mTGlzdC5CeURheXMpXCJcbiAgICAvPlxuICAgIDx1bD5cbiAgICAgIDxsaSB0aXRsZT1cIlRvZGF5XCI+XG4gICAgICAgIDxsYWJlbCBmb3I9XCJ0b2RheVRhYlwiIHJvbGU9XCJidXR0b25cIlxuICAgICAgICAgID48c3Bhbj57eyB0KCd0b2RheS5tZXNzYWdlJykgfX08L3NwYW4+PC9sYWJlbFxuICAgICAgICA+XG4gICAgICA8L2xpPlxuICAgICAgPGxpIHRpdGxlPVwiQWxsIFRoZSBUaW1lXCI+XG4gICAgICAgIDxsYWJlbCBmb3I9XCJhbGxUaW1lVGFiXCIgcm9sZT1cImJ1dHRvblwiXG4gICAgICAgICAgPjxzcGFuPnt7IHQoJ2FsbFRpbWUubWVzc2FnZScpIH19PC9zcGFuPjwvbGFiZWxcbiAgICAgICAgPlxuICAgICAgPC9saT5cbiAgICAgIDxsaSB0aXRsZT1cIkJ5IERheXNcIj5cbiAgICAgICAgPGxhYmVsIGZvcj1cImJ5RGF5c1RhYlwiIHJvbGU9XCJidXR0b25cIlxuICAgICAgICAgID48c3Bhbj57eyB0KCdieURheXMubWVzc2FnZScpIH19PC9zcGFuPjwvbGFiZWxcbiAgICAgICAgPlxuICAgICAgPC9saT5cbiAgICA8L3VsPlxuXG4gICAgPGRpdiBjbGFzcz1cInNsaWRlclwiPjxkaXYgY2xhc3M9XCJpbmRpY2F0b3JcIj48L2Rpdj48L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPlxuICAgICAgPHNlY3Rpb24gaWQ9XCJ0b2RheVRhYkxpc3RcIj5cbiAgICAgICAgPFRhYkxpc3RcbiAgICAgICAgICB2LWlmPVwiYWN0aXZlVGFiID09IFR5cGVPZkxpc3QuVG9kYXlcIlxuICAgICAgICAgIDp0eXBlPVwiVHlwZU9mTGlzdC5Ub2RheVwiXG4gICAgICAgICAgOnNob3dBbGxTdGF0cz1cImZhbHNlXCJcbiAgICAgICAgLz5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGlkPVwic3VtbWFyeVwiPlxuICAgICAgICA8VGFiTGlzdCB2LWlmPVwiYWN0aXZlVGFiID09IFR5cGVPZkxpc3QuQWxsXCIgOnR5cGU9XCJUeXBlT2ZMaXN0LkFsbFwiIDpzaG93QWxsU3RhdHM9XCJ0cnVlXCIgLz5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGlkPVwiYnlEYXlzVGFiTGlzdFwiPlxuICAgICAgICA8QnlEYXlzIHYtaWY9XCJhY3RpdmVUYWIgPT0gVHlwZU9mTGlzdC5CeURheXNcIiAvPlxuICAgICAgPC9zZWN0aW9uPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgbGFuZz1cInRzXCIgc2V0dXA+XG5pbXBvcnQgeyBvbk1vdW50ZWQsIHJlZiB9IGZyb20gJ3Z1ZSc7XG5pbXBvcnQgeyB1c2VJMThuIH0gZnJvbSAndnVlLWkxOG4nO1xuaW1wb3J0IEJ5RGF5cyBmcm9tICcuLi9jb21wb25lbnRzL0J5RGF5cy52dWUnO1xuaW1wb3J0IFRhYkxpc3QgZnJvbSAnLi4vY29tcG9uZW50cy9UYWJMaXN0LnZ1ZSc7XG5pbXBvcnQgeyBpbmplY3RTdG9yYWdlIH0gZnJvbSAnLi4vc3RvcmFnZS9pbmplY3Qtc3RvcmFnZSc7XG5pbXBvcnQgeyBTZXR0aW5nc1RhYiwgVHlwZU9mTGlzdCB9IGZyb20gJy4uL3V0aWxzL2VudW1zJztcbmltcG9ydCB7IG9wZW5QYWdlIH0gZnJvbSAnLi4vdXRpbHMvb3Blbi1wYWdlJztcblxuY29uc3QgeyB0IH0gPSB1c2VJMThuKCk7XG5cblxuY29uc3QgYWN0aXZlVGFiID0gcmVmPFR5cGVPZkxpc3Q+KCk7XG5cbm9uTW91bnRlZChhc3luYyAoKSA9PiB7XG4gIGFjdGl2ZVRhYi52YWx1ZSA9IFR5cGVPZkxpc3QuVG9kYXk7XG59KTtcblxuZnVuY3Rpb24gc2VsZWN0VGFiKHR5cGU6IFR5cGVPZkxpc3QpIHtcbiAgYWN0aXZlVGFiLnZhbHVlID0gdHlwZTtcbn1cblxuZnVuY3Rpb24gdXBkYXRlVGFiKCkge1xuICBjb25zdCB0ZW1wVmFsdWUgPSBhY3RpdmVUYWIudmFsdWU7XG4gIGFjdGl2ZVRhYi52YWx1ZSA9IHVuZGVmaW5lZDtcbiAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgYWN0aXZlVGFiLnZhbHVlID0gdGVtcFZhbHVlO1xuICB9LCA1MCk7XG59XG48L3NjcmlwdD5cblxuPHN0eWxlIHNjb3BlZD5cbi5oZWFkZXJCbG9jayB7XG4gIGhlaWdodDogNTJweDtcbn1cbi5oZWFkZXJCbG9jayAuaGVhZGVyIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBwYWRkaW5nOiAwIDAgMCA1cHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6ICM0YTRhNGE7XG4gIHZlcnRpY2FsLWFsaWduOiB0ZXh0LWJvdHRvbTtcbn1cblxuLmhlYWRlckJsb2NrIGltZyB7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgcGFkZGluZzogMTBweDtcbn1cbi5oZWFkZXJCbG9jayAubG9nbyB7XG4gIG1hcmdpbi1sZWZ0OiA3cHg7XG59XG4uaGVhZGVyQmxvY2sgLmljb25zLWJsb2NrIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW46IDdweCAwIDAgMDtcbn1cblxuLmhlYWRlckJsb2NrIC5pY29ucy1ibG9jayBhOmhvdmVyIHtcbiAgZmlsdGVyOiBpbnZlcnQoNDAlKSBzZXBpYSg5NCUpIHNhdHVyYXRlKDMzNzElKSBodWUtcm90YXRlKDIyN2RlZykgYnJpZ2h0bmVzcyg5OSUpIGNvbnRyYXN0KDkyJSk7XG59XG5cbi5oZWFkZXJCbG9jayAuaWNvbnMtYmxvY2sgYSB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBmb250LXdlaWdodDogNjAwO1xufVxuXG4uaGVhZGVyQmxvY2sgLmljb25zLWJsb2NrIGEgaW1nIHtcbiAgdmVydGljYWwtYWxpZ246IG1pZGRsZTtcbiAgcGFkZGluZy1sZWZ0OiA1cHggIWltcG9ydGFudDtcbn1cbi5oZWFkZXJCbG9jayAuaWNvbnMtYmxvY2sge1xuICB2ZXJ0aWNhbC1hbGlnbjogbWlkZGxlO1xufVxuPC9zdHlsZT5cbiIsImltcG9ydCBQb3B1cCBmcm9tICcuL3BhZ2VzL1BvcHVwLnZ1ZSc7XG5pbXBvcnQgVnVlRGF0ZVBpY2tlciBmcm9tICdAdnVlcGljL3Z1ZS1kYXRlcGlja2VyJztcbmltcG9ydCAnQHZ1ZXBpYy92dWUtZGF0ZXBpY2tlci9kaXN0L21haW4uY3NzJztcbmltcG9ydCB7IGNyZWF0ZUFwcCB9IGZyb20gJ3Z1ZSc7XG5pbXBvcnQgaTE4biBmcm9tICcuL3BsdWdpbnMvaTE4bic7XG5cbmNvbnN0IGFwcCA9IGNyZWF0ZUFwcChQb3B1cCk7XG5hcHAuY29tcG9uZW50KCdWdWVEYXRlUGlja2VyJywgVnVlRGF0ZVBpY2tlcik7XG5hcHAudXNlKGkxOG4pO1xuYXBwLm1vdW50KCdib2R5Jyk7XG4iXSwibmFtZXMiOlsiX19kZWZhdWx0X18iLCJWdWVEYXRlUGlja2VyIl0sIm1hcHBpbmdzIjoiOztBQUFBLE1BQWUsYUFBQTtBQ0FmLE1BQWUsYUFBQTs7Ozs7Ozs7Ozs7Ozs7QUM0QmYsTUFBQUEsZ0JBQWU7QUFBQSxFQUNiLE1BQU07QUFDUjs7Ozs7Ozs7QUFZQSxVQUFNLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDd0JiLE1BQUEsY0FBZTtBQUFBLEVBQ2IsTUFBTTtBQUNSOzs7O0FBaUJNLFVBQUEsRUFBRSxNQUFNO0FBRWQsVUFBTSxhQUFhO0FBQ25CLFVBQU0sWUFBWTtBQUNsQixVQUFNLFNBQVM7QUFDZixVQUFNLGVBQWU7QUFFckIsVUFBTSxlQUFlO0FBRXJCLFVBQU0sY0FBYztBQUFBLE1BQVMsTUFDM0IsV0FBVyxTQUFTLFNBQVksV0FBVyxNQUFNLEtBQUssU0FBUztBQUFBLElBQUE7QUFHbEQsbUJBQUEsU0FBUyxVQUFnQixRQUFjO0FBQ3BELFlBQU0sVUFBVSxNQUFNLGlCQUFpQixVQUFVLE1BQU07QUFDdkQsVUFBSSxXQUFXLE1BQU07QUFDbkIsbUJBQVcsUUFBUTtBQUNuQixZQUFJLFFBQVEsS0FBSyxVQUFVLEtBQUssUUFBUSxlQUFlO0FBQUcsaUJBQU8sUUFBUTtBQUFBO0FBQ3BFLGlCQUFPLFFBQVE7QUFBQSxNQUN0QjtBQUNBLGdCQUFVLFFBQVE7QUFBQSxJQUNwQjtBQUVBLG1CQUFlLFdBQVcsV0FBbUI7O0FBQzNDLG1CQUFhLFFBQVE7QUFDZixZQUFBLFlBQVcsa0JBQWEsVUFBYixtQkFBcUI7QUFDaEMsWUFBQSxVQUFTLGtCQUFhLFVBQWIsbUJBQXFCO0FBQzlCLFlBQUEsU0FBUyxVQUFVLE1BQU07QUFBQSxJQUNqQztBQUVBLGNBQVUsWUFBWTs7QUFDcEIsZ0JBQVUsUUFBUTtBQUNsQixtQkFBYSxRQUFRO0FBQ2YsWUFBQSxZQUFXLGtCQUFhLFVBQWIsbUJBQXFCO0FBQ2hDLFlBQUEsVUFBUyxrQkFBYSxVQUFiLG1CQUFxQjtBQUM5QixZQUFBLFNBQVMsVUFBVSxNQUFNO0FBQUEsSUFBQSxDQUNoQztBQUVELG1CQUFlLGNBQWM7O0FBQ3JCLFlBQUEsWUFBVyxrQkFBYSxVQUFiLG1CQUFxQjtBQUNoQyxZQUFBLFVBQVMsa0JBQWEsVUFBYixtQkFBcUI7QUFDcEMsWUFBTSxNQUFNLE1BQU0sd0JBQXVCLGdCQUFXLFVBQVgsbUJBQWtCLElBQUk7QUFDL0Q7QUFBQSxRQUNFO0FBQUEsUUFDQSxTQUFTO0FBQUEsUUFDVCxZQUFZLFNBQVMsbUJBQW9CLENBQUEsSUFBSSxPQUFPLG1CQUFvQixDQUFBO0FBQUEsTUFBQTtBQUFBLElBRTVFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25ETSxVQUFBLEVBQUUsTUFBTTtBQUdkLFVBQU0sWUFBWTtBQUVsQixjQUFVLFlBQVk7QUFDcEIsZ0JBQVUsUUFBUSxXQUFXO0FBQUEsSUFBQSxDQUM5QjtBQUVELGFBQVMsVUFBVSxNQUFrQjtBQUNuQyxnQkFBVSxRQUFRO0FBQUEsSUFDcEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEZBLE1BQU0sTUFBTSxVQUFVLEtBQUs7QUFDM0IsSUFBSSxVQUFVLGlCQUFpQkMsRUFBYTtBQUM1QyxJQUFJLElBQUksSUFBSTtBQUNaLElBQUksTUFBTSxNQUFNOzsifQ==
