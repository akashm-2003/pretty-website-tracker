import { a as ref, q as computed, ao as getStringTab, d as defineComponent, l as useI18n, an as computedAsync, o as openBlock, c as createElementBlock, b as createBaseVNode, f as toDisplayString, u as unref, B as _imports_0, C as createCommentVNode, aS as CHROME_STORE_CLEAR_YOUTUBE_URL, S as StorageParams, D as injectStorage, _ as _export_sfc } from "./general.js";
const QUERY_PARAMS_DASHBOARD = "dashboard.html";
const QUERY_PARAMS_TAB = "tab";
const QUERY_PARAMS_TAB_LIMITS = "limits";
const QUERY_PARAMS_BLOCK = "block.html";
const QUERY_PARAMS_BLOCK_DOMAIN = "domain";
function useExtensionPage() {
  const urlObj = ref(new URL(location.href));
  const isLimitPage = computed(
    () => urlObj.value.hostname == "hhfnghjdeddcfegfekjeihfmbjenlomm" && urlObj.value.pathname.includes(QUERY_PARAMS_DASHBOARD) && urlObj.value.searchParams.get(QUERY_PARAMS_TAB) == QUERY_PARAMS_TAB_LIMITS
  );
  const isBlockPage = computed(
    () => {
      var _a;
      return urlObj.value.hostname == "hhfnghjdeddcfegfekjeihfmbjenlomm" && urlObj.value.pathname.includes(QUERY_PARAMS_BLOCK) && ((_a = urlObj.value.searchParams.get(QUERY_PARAMS_BLOCK_DOMAIN)) == null ? void 0 : _a.includes("youtube.com"));
    }
  );
  function updateTab(tab) {
    let targetTab = getStringTab(tab);
    const currentTab = urlObj.value.searchParams.get(QUERY_PARAMS_TAB);
    if (window.history.replaceState && currentTab) {
      const sourceUrl = `tab=${currentTab}`;
      const targetUrl = `tab=${targetTab}`;
      window.history.replaceState(
        location.href,
        document.title,
        location.href.replace(sourceUrl, targetUrl)
      );
      urlObj.value = new URL(location.href);
    }
  }
  return {
    isLimitPage,
    isBlockPage,
    updateTab
  };
}
const _hoisted_1 = {
  key: 0,
  class: "review-block"
};
const _hoisted_2 = { class: "btn-block" };
const _hoisted_3 = ["value"];
const __default__ = {
  name: "PromoClearYouTube"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  ...__default__,
  setup(__props) {
    const { t } = useI18n();
    const settingsStorage = injectStorage();
    const extensionPage = useExtensionPage();
    const showReview = ref(true);
    computedAsync(async () => await usePromoExtension());
    async function closeBlock() {
      showReview.value = false;
      await saveValue();
    }
    async function openStore() {
      showReview.value = false;
      window.open(CHROME_STORE_CLEAR_YOUTUBE_URL, "_blank");
      await saveValue();
    }
    async function saveValue() {
      let param = void 0;
      if (extensionPage.isBlockPage.value)
        param = StorageParams.PROMO_CLEAR_YOUTUBE_ON_BLOCK;
      if (extensionPage.isLimitPage.value)
        param = StorageParams.PROMO_CLEAR_YOUTUBE_ON_LIMITS;
      if (param)
        await settingsStorage.saveValue(param, true);
    }
    return (_ctx, _cache) => {
      return showReview.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("p", null, toDisplayString(unref(t)("promoClearYoutube.message")), 1),
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("img", {
            height: "15",
            src: _imports_0,
            onClick: _cache[0] || (_cache[0] = ($event) => closeBlock())
          }),
          createBaseVNode("input", {
            type: "button",
            value: unref(t)("promoClearYoutube.description"),
            onClick: _cache[1] || (_cache[1] = ($event) => openStore())
          }, null, 8, _hoisted_3)
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const PromoClearYouTube_vue_vue_type_style_index_0_scoped_9adad115_lang = "";
const PromoClearYouTube = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-9adad115"]]);
export {
  PromoClearYouTube as P,
  useExtensionPage as u
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiUHJvbW9DbGVhcllvdVR1YmUuanMiLCJzb3VyY2VzIjpbIi4uL3NyYy9jb21wb3NpdGlvbnMvdXNlRXh0ZW5zaW9uUGFnZS50cyIsIi4uL3NyYy9jb21wb25lbnRzL1Byb21vQ2xlYXJZb3VUdWJlLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjb21wdXRlZCwgcmVmIH0gZnJvbSAndnVlJztcbmltcG9ydCB7IFNldHRpbmdzVGFiIH0gZnJvbSAnLi4vdXRpbHMvZW51bXMnO1xuaW1wb3J0IHsgZ2V0U3RyaW5nVGFiIH0gZnJvbSAnLi4vdXRpbHMvZXh0ZW5zaW9uLXRhYnMnO1xuXG5leHBvcnQgY29uc3QgUVVFUllfUEFSQU1TX0RBU0hCT0FSRCA9ICdkYXNoYm9hcmQuaHRtbCc7XG5leHBvcnQgY29uc3QgUVVFUllfUEFSQU1TX1RBQiA9ICd0YWInO1xuZXhwb3J0IGNvbnN0IFFVRVJZX1BBUkFNU19UQUJfTElNSVRTID0gJ2xpbWl0cyc7XG5leHBvcnQgY29uc3QgUVVFUllfUEFSQU1TX0JMT0NLID0gJ2Jsb2NrLmh0bWwnO1xuZXhwb3J0IGNvbnN0IFFVRVJZX1BBUkFNU19CTE9DS19ET01BSU4gPSAnZG9tYWluJztcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUV4dGVuc2lvblBhZ2UoKSB7XG4gIGNvbnN0IHVybE9iaiA9IHJlZihuZXcgVVJMKGxvY2F0aW9uLmhyZWYpKTtcblxuICBjb25zdCBpc0xpbWl0UGFnZSA9IGNvbXB1dGVkKFxuICAgICgpID0+XG4gICAgICB1cmxPYmoudmFsdWUuaG9zdG5hbWUgPT0gX19BUFBfSURfXyAmJlxuICAgICAgdXJsT2JqLnZhbHVlLnBhdGhuYW1lLmluY2x1ZGVzKFFVRVJZX1BBUkFNU19EQVNIQk9BUkQpICYmXG4gICAgICB1cmxPYmoudmFsdWUuc2VhcmNoUGFyYW1zLmdldChRVUVSWV9QQVJBTVNfVEFCKSA9PSBRVUVSWV9QQVJBTVNfVEFCX0xJTUlUUyxcbiAgKTtcblxuICBjb25zdCBpc0Jsb2NrUGFnZSA9IGNvbXB1dGVkKFxuICAgICgpID0+XG4gICAgICB1cmxPYmoudmFsdWUuaG9zdG5hbWUgPT0gX19BUFBfSURfXyAmJlxuICAgICAgdXJsT2JqLnZhbHVlLnBhdGhuYW1lLmluY2x1ZGVzKFFVRVJZX1BBUkFNU19CTE9DSykgJiZcbiAgICAgIHVybE9iai52YWx1ZS5zZWFyY2hQYXJhbXMuZ2V0KFFVRVJZX1BBUkFNU19CTE9DS19ET01BSU4pPy5pbmNsdWRlcygneW91dHViZS5jb20nKSxcbiAgKTtcblxuICBmdW5jdGlvbiB1cGRhdGVUYWIodGFiOiBTZXR0aW5nc1RhYikge1xuICAgIGxldCB0YXJnZXRUYWIgPSBnZXRTdHJpbmdUYWIodGFiKTtcbiAgICBjb25zdCBjdXJyZW50VGFiID0gdXJsT2JqLnZhbHVlLnNlYXJjaFBhcmFtcy5nZXQoUVVFUllfUEFSQU1TX1RBQik7XG4gICAgaWYgKHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZSAmJiBjdXJyZW50VGFiKSB7XG4gICAgICBjb25zdCBzb3VyY2VVcmwgPSBgdGFiPSR7Y3VycmVudFRhYn1gO1xuICAgICAgY29uc3QgdGFyZ2V0VXJsID0gYHRhYj0ke3RhcmdldFRhYn1gO1xuICAgICAgd2luZG93Lmhpc3RvcnkucmVwbGFjZVN0YXRlKFxuICAgICAgICBsb2NhdGlvbi5ocmVmLFxuICAgICAgICBkb2N1bWVudC50aXRsZSxcbiAgICAgICAgbG9jYXRpb24uaHJlZi5yZXBsYWNlKHNvdXJjZVVybCwgdGFyZ2V0VXJsKSxcbiAgICAgICk7XG4gICAgICB1cmxPYmoudmFsdWUgPSBuZXcgVVJMKGxvY2F0aW9uLmhyZWYpO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiB7XG4gICAgaXNMaW1pdFBhZ2UsXG4gICAgaXNCbG9ja1BhZ2UsXG4gICAgdXBkYXRlVGFiLFxuICB9O1xufVxuIiwiPHRlbXBsYXRlPlxuICA8ZGl2IGNsYXNzPVwicmV2aWV3LWJsb2NrXCIgdi1pZj1cInNob3dSZXZpZXdcIj5cbiAgICA8cD57eyB0KCdwcm9tb0NsZWFyWW91dHViZS5tZXNzYWdlJykgfX08L3A+XG4gICAgPGRpdiBjbGFzcz1cImJ0bi1ibG9ja1wiPlxuICAgICAgPGltZyBoZWlnaHQ9XCIxNVwiIHNyYz1cIi4uL2Fzc2V0cy9pY29ucy9jbG9zZS5zdmdcIiBAY2xpY2s9XCJjbG9zZUJsb2NrKClcIiAvPlxuICAgICAgPGlucHV0IHR5cGU9XCJidXR0b25cIiA6dmFsdWU9XCJ0KCdwcm9tb0NsZWFyWW91dHViZS5kZXNjcmlwdGlvbicpXCIgQGNsaWNrPVwib3BlblN0b3JlKClcIiAvPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgbGFuZz1cInRzXCI+XG5leHBvcnQgZGVmYXVsdCB7XG4gIG5hbWU6ICdQcm9tb0NsZWFyWW91VHViZScsXG59O1xuPC9zY3JpcHQ+XG5cbjxzY3JpcHQgbGFuZz1cInRzXCIgc2V0dXA+XG5pbXBvcnQgeyByZWYgfSBmcm9tICd2dWUnO1xuaW1wb3J0IHsgdXNlSTE4biB9IGZyb20gJ3Z1ZS1pMThuJztcbmltcG9ydCB7IGluamVjdFN0b3JhZ2UgfSBmcm9tICcuLi9zdG9yYWdlL2luamVjdC1zdG9yYWdlJztcbmltcG9ydCB7IFN0b3JhZ2VQYXJhbXMgfSBmcm9tICcuLi9zdG9yYWdlL3N0b3JhZ2UtcGFyYW1zJztcbmltcG9ydCB7IENIUk9NRV9TVE9SRV9DTEVBUl9ZT1VUVUJFX1VSTCB9IGZyb20gJy4uL3V0aWxzL2Nocm9tZS11cmwnO1xuaW1wb3J0IHsgY29tcHV0ZWRBc3luYyB9IGZyb20gJ0B2dWV1c2UvY29yZSc7XG5pbXBvcnQgeyB1c2VFeHRlbnNpb25QYWdlIH0gZnJvbSAnLi4vY29tcG9zaXRpb25zL3VzZUV4dGVuc2lvblBhZ2UnO1xuXG5jb25zdCB7IHQgfSA9IHVzZUkxOG4oKTtcblxuY29uc3Qgc2V0dGluZ3NTdG9yYWdlID0gaW5qZWN0U3RvcmFnZSgpO1xuY29uc3QgZXh0ZW5zaW9uUGFnZSA9IHVzZUV4dGVuc2lvblBhZ2UoKTtcblxuY29uc3Qgc2hvd1JldmlldyA9IHJlZjxib29sZWFuPih0cnVlKTtcblxuY29uc3QgY2FuU2hvd1Byb21vID0gY29tcHV0ZWRBc3luYyhhc3luYyAoKSA9PiBhd2FpdCB1c2VQcm9tb0V4dGVuc2lvbigpKTtcblxuYXN5bmMgZnVuY3Rpb24gY2xvc2VCbG9jaygpIHtcbiAgc2hvd1Jldmlldy52YWx1ZSA9IGZhbHNlO1xuICBhd2FpdCBzYXZlVmFsdWUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gb3BlblN0b3JlKCkge1xuICBzaG93UmV2aWV3LnZhbHVlID0gZmFsc2U7XG4gIHdpbmRvdy5vcGVuKENIUk9NRV9TVE9SRV9DTEVBUl9ZT1VUVUJFX1VSTCwgJ19ibGFuaycpO1xuICBhd2FpdCBzYXZlVmFsdWUoKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2F2ZVZhbHVlKCkge1xuICBsZXQgcGFyYW06IFN0b3JhZ2VQYXJhbXMgfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG4gIGlmIChleHRlbnNpb25QYWdlLmlzQmxvY2tQYWdlLnZhbHVlKSBwYXJhbSA9IFN0b3JhZ2VQYXJhbXMuUFJPTU9fQ0xFQVJfWU9VVFVCRV9PTl9CTE9DSztcbiAgaWYgKGV4dGVuc2lvblBhZ2UuaXNMaW1pdFBhZ2UudmFsdWUpIHBhcmFtID0gU3RvcmFnZVBhcmFtcy5QUk9NT19DTEVBUl9ZT1VUVUJFX09OX0xJTUlUUztcbiAgaWYgKHBhcmFtKSBhd2FpdCBzZXR0aW5nc1N0b3JhZ2Uuc2F2ZVZhbHVlKHBhcmFtLCB0cnVlKTtcbn1cbjwvc2NyaXB0PlxuXG48c3R5bGUgc2NvcGVkPlxuLnJldmlldy1ibG9jayB7XG4gIG1hcmdpbjogMjBweCAwIDIwcHggMDtcbiAgcGFkZGluZzogMTBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZWZlZmVmO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtaW4td2lkdGg6IDY1NXB4O1xufVxuLnJldmlldy1ibG9jayAuYnRuLWJsb2NrIHtcbiAgbWFyZ2luOiA4cHggNXB4IDAgMDtcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuLnJldmlldy1ibG9jayBpbnB1dFt0eXBlPSdidXR0b24nXSB7XG4gIGZsb2F0OiByaWdodDtcbiAgd2lkdGg6IGF1dG87XG59XG4ucmV2aWV3LWJsb2NrIHAge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIG1hcmdpbjogMCAxMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIHdpZHRoOiA3MCU7XG59XG4ucmV2aWV3LWJsb2NrIGltZyB7XG4gIG1hcmdpbi1sZWZ0OiA4cHg7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgZmxvYXQ6IHJpZ2h0O1xufVxuPC9zdHlsZT5cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBSU8sTUFBTSx5QkFBeUI7QUFDL0IsTUFBTSxtQkFBbUI7QUFDekIsTUFBTSwwQkFBMEI7QUFDaEMsTUFBTSxxQkFBcUI7QUFDM0IsTUFBTSw0QkFBNEI7QUFFbEMsU0FBUyxtQkFBbUI7QUFDakMsUUFBTSxTQUFTLElBQUksSUFBSSxJQUFJLFNBQVMsSUFBSSxDQUFDO0FBRXpDLFFBQU0sY0FBYztBQUFBLElBQ2xCLE1BQ0UsT0FBTyxNQUFNLFlBQVksc0NBQ3pCLE9BQU8sTUFBTSxTQUFTLFNBQVMsc0JBQXNCLEtBQ3JELE9BQU8sTUFBTSxhQUFhLElBQUksZ0JBQWdCLEtBQUs7QUFBQSxFQUFBO0FBR3ZELFFBQU0sY0FBYztBQUFBLElBQ2xCLE1BQ0U7O0FBQUEsb0JBQU8sTUFBTSxZQUFZLHNDQUN6QixPQUFPLE1BQU0sU0FBUyxTQUFTLGtCQUFrQixPQUNqRCxZQUFPLE1BQU0sYUFBYSxJQUFJLHlCQUF5QixNQUF2RCxtQkFBMEQsU0FBUztBQUFBO0FBQUEsRUFBYTtBQUdwRixXQUFTLFVBQVUsS0FBa0I7QUFDL0IsUUFBQSxZQUFZLGFBQWEsR0FBRztBQUNoQyxVQUFNLGFBQWEsT0FBTyxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7QUFDN0QsUUFBQSxPQUFPLFFBQVEsZ0JBQWdCLFlBQVk7QUFDdkMsWUFBQSxZQUFZLE9BQU8sVUFBVTtBQUM3QixZQUFBLFlBQVksT0FBTyxTQUFTO0FBQ2xDLGFBQU8sUUFBUTtBQUFBLFFBQ2IsU0FBUztBQUFBLFFBQ1QsU0FBUztBQUFBLFFBQ1QsU0FBUyxLQUFLLFFBQVEsV0FBVyxTQUFTO0FBQUEsTUFBQTtBQUU1QyxhQUFPLFFBQVEsSUFBSSxJQUFJLFNBQVMsSUFBSTtBQUFBLElBQ3RDO0FBQUEsRUFDRjtBQUVPLFNBQUE7QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFBO0FBRUo7Ozs7Ozs7QUNwQ0EsTUFBQSxjQUFlO0FBQUEsRUFDYixNQUFNO0FBQ1I7Ozs7QUFZTSxVQUFBLEVBQUUsTUFBTTtBQUVkLFVBQU0sa0JBQWtCO0FBQ3hCLFVBQU0sZ0JBQWdCO0FBRWhCLFVBQUEsYUFBYSxJQUFhLElBQUk7QUFFZixrQkFBYyxZQUFZLE1BQU0sbUJBQW1CO0FBRXhFLG1CQUFlLGFBQWE7QUFDMUIsaUJBQVcsUUFBUTtBQUNuQixZQUFNLFVBQVU7QUFBQSxJQUNsQjtBQUVBLG1CQUFlLFlBQVk7QUFDekIsaUJBQVcsUUFBUTtBQUNaLGFBQUEsS0FBSyxnQ0FBZ0MsUUFBUTtBQUNwRCxZQUFNLFVBQVU7QUFBQSxJQUNsQjtBQUVBLG1CQUFlLFlBQVk7QUFDekIsVUFBSSxRQUFtQztBQUN2QyxVQUFJLGNBQWMsWUFBWTtBQUFPLGdCQUFRLGNBQWM7QUFDM0QsVUFBSSxjQUFjLFlBQVk7QUFBTyxnQkFBUSxjQUFjO0FBQ3ZELFVBQUE7QUFBYSxjQUFBLGdCQUFnQixVQUFVLE9BQU8sSUFBSTtBQUFBLElBQ3hEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OyJ9
